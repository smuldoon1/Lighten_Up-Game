﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TestFlammable : Flammable {

    public float testFireStrength = 1;
    public float testWaterStrength = 20;

    public override void Update () {
        base.Update();
        // Temp code to mimic candle interaction
        if (Input.GetKey(KeyCode.F))
        {
            Burn(testFireStrength);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Extinguish(testWaterStrength);
        }
	}
}
