﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Flammable : MonoBehaviour {

    public static float burnRate = 0.1f; // Changes the overall rate of fire increasing/decreasing
    public static bool visibleBurning = true;

    public float sustainThreshold; // The threshold to be reached before the fire will start to burn on its own
    public float maxBurning; // The maximum 'health' of the object before the fire stops and the object is considered fully burnt
    public float maxWaterlogging; // How waterlogged the object can become, should be a negative value
    public float currentBurn; // The current 'health' of the object
    public float fireSpreadRadius;

    Flammable[] nearbyFlammables; // Holds an array of nearby objects that fire will spread to

    Slider healthBar;
    Image sliderFill;
    Material mat;
    Vector3 currentColor;
    float percentageFilled;

    private void Start()
    {
        HouseHealth.Add(this);
        nearbyFlammables = GetFlammables(fireSpreadRadius);

        if (transform.Find("Canvas").GetComponentInChildren<Slider>() != null && visibleBurning)
        {
            healthBar = transform.Find("Canvas").GetComponentInChildren<Slider>();
            sliderFill = healthBar.transform.Find("Fill Area").GetComponentInChildren<Image>();
            healthBar.gameObject.SetActive(false);
        }
        if (visibleBurning)
        {
            mat = GetComponent<MeshRenderer>().material;
        }
    }

    public virtual void Update()
    {
        if ((currentBurn > 0) && (currentBurn < maxBurning))
        {
            if (currentBurn < sustainThreshold)
            {
                currentBurn -= burnRate * (1 - (currentBurn / sustainThreshold));
                if (currentBurn < 0)
                {
                    currentBurn = 0;
                }
            }
            else
            {
                Burn(burnRate * (currentBurn - sustainThreshold) / (maxBurning - sustainThreshold));
                BurnNearby();
            }
        }
        if (visibleBurning)
        {
            UpdateMaterial();
        }    }

    public void Burn(float burnStrength)
    {
        currentBurn += burnStrength;
        if (currentBurn > maxBurning)
        {
            currentBurn = maxBurning;
        }
    }

    public void Extinguish(float waterAmount)
    {
        if (currentBurn != maxBurning)
        {
            currentBurn -= waterAmount;
            if (currentBurn < maxWaterlogging)
            {
                currentBurn = maxWaterlogging;
            }
        }
    }

    /// <summary>
    /// Burns the nearby flammable objects.
    /// </summary>
    private void BurnNearby()
    {
        if (nearbyFlammables != null)
        {
            foreach (Flammable obj in nearbyFlammables)
            {
                obj.Burn(100 / currentBurn);
            }
        }
    }

    /// <summary>
    /// Gets all the nearby flammable objects within a radius.
    /// </summary>
    /// <param name="radius"></param>
    /// <returns></returns>
    private Flammable[] GetFlammables(float radius)
    {
        List<Flammable> flammables = new List<Flammable>();
        foreach (Collider obj in Physics.OverlapSphere(transform.position, radius))
        {
            if (obj.gameObject.GetComponent<Flammable>() != null && obj.gameObject != gameObject)
            {
                flammables.Add(obj.GetComponent<Flammable>());
            }
        }
        return flammables.ToArray();
    }


    /// <summary>
    /// Updates the material to reflect the waterlogged, burning or burnt out state.
    /// </summary>
    private void UpdateMaterial()
    {
        if (currentBurn >= 0 && currentBurn < maxBurning)
        {
            percentageFilled = currentBurn / maxBurning;
            currentColor = new Vector3(2, 1, 0);
            sliderFill.color = new Color(1, 0.7f, 0);
        }
        else if (currentBurn == maxBurning)
        {
            percentageFilled = 1;
            currentColor = new Vector3(0.1f, 0.1f, 0.1f);
        }
        else
        {
            percentageFilled = currentBurn / maxWaterlogging;
            currentColor = new Vector3(0, 0.3f, 0.5f);
            sliderFill.color = new Color(0, 0.7f, 1);
        }
        if (percentageFilled == 0 || percentageFilled == 1)
        {
            healthBar.gameObject.SetActive(false);
        }
        else
        {
            healthBar.gameObject.SetActive(true);
            healthBar.value = percentageFilled;
        }
        mat.color = new Color(1 - percentageFilled * (1 - currentColor.x), 1 - percentageFilled * (1 - currentColor.y), 1 - percentageFilled * (1 - currentColor.z));
    }
}
