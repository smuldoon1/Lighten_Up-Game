﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HouseHealth : MonoBehaviour {

    static List<Flammable> allFlammables = new List<Flammable>(); // Stores each flammable object so to keep track of the houses current 'health'
    static float totalHealth; // The combined 'max burning' of all flammables in the house
    float currentHealth; // The current damage done to the house
    Slider healthBar;

    private void Start()
    {
        healthBar = GetComponentInChildren<Slider>();
    }

    private void Update()
    {
        float current = 0;
        foreach (Flammable obj in allFlammables)
        {
            if (obj.currentBurn > 0)
            {
                current += obj.currentBurn;
            }
        }
        healthBar.value = current / totalHealth;
    }

    /// <summary>
    /// Adds a flammable object to the house.
    /// </summary>
    /// <param name="flammable"></param>
    public static void Add(Flammable flammable)
    {
        allFlammables.Add(flammable);
        totalHealth += flammable.maxBurning;
    }
}
